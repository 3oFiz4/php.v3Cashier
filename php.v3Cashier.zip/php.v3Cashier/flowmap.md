# Background

Implement Model-View-Control (MVC), relational data management, authentication, and business logic in development of a web with a framework (CI4). Create a application called Point of Sale (POS) minimarket named Ramstore. With a purpose of, automated data iput of a master stock and also the ability to process transaction of product sales in a minimarket in real-time. Use CodeIgniter4 for the framework, there is also @folder:references/ regarding our previous PoS program but in pure PHP.

# Role

A: Admin: Have full ownership to do any management of the user database including admin and cashier data (CRUD operation); Operate stock/product catalog, and including their category/variation, while able to monitor the transaction history report.

B: Cashier: Have ownership to operate the transaction module, ability to print a receipt of a payment, and also a list of transaction that is processed under the work.

# Database Architecture Specification

a. admin table: Stores system administrator information, including admin ID, full name, username, encrypted password, and registration timestamp.

b. kasir (cashier) table: Stores cashier data, including cashier ID, full name, username, encrypted password, contact number, and an enumeration shift column ('Morning', 'Afternoon', 'Night') to indicate work shifts.

c. jenis_barang (item_category) table: Holds classifications or categories for minimarket products (such as Snacks, Beverages, Personal Care, and Household/Kitchen Essentials).

d. barang (item/product) table: Stores the minimarket product catalog, linked to the jenis_barang table via a foreign key, and contains details such as barcode, product name, cost price, selling price, and available stock.

e. transaksi (transaction) table: Serves as the receipt/invoice header, recording transaction ID, unique receipt number, transaction date/time, on-duty cashier ID (foreign key), total amount, amount paid, and change due.

f. detail_transaksi (transaction_details) table: Contains line items purchased under a single receipt number through relations to the transaction ID and product ID, storing the unit price at transaction time, quantity purchased, and calculated subtotal.

g. and possibly more if necessary

# Functional Features

- **Multi-Item Transaction Management:** The transaction module on the cashier account must be able to handle more than one type of item in a single transaction/receipt process.

- **Automatic Calculation:** The system must calculate the subtotal value per item, the accumulated total purchase amount, and the change due based on the cash amount entered by the cashier.

- **Stock Automation & Validation:** Every successfully recorded transaction must automatically reduce item stock quantities in the `barang` (items) table. If the quantity of items requested exceeds the remaining available stock, the system must reject the transaction and display a warning message.

# Other features

Other features that can be implemented, feature encapsulated in `~` and `~` indicate that the feature SHOULD NOT be developed yet.

1. Barcode Scanner Emulation: Listens for rapid input from USB or wireless barcode scanners to automatically search and add products to the active cart without manual clicks; scanning a bottle of mineral water immediately adds it to the transaction list with quantity 1.

2. Shift Cash Reconciliation: Tracks starting cash float, recorded sales, and physical cash counted at the end of each shift to detect cash drawer discrepancies; an afternoon cashier counts Rp 1,500,000 against a system record of Rp 1,520,000, logging a Rp 20,000 cash shortage.

3. Multi-Payment & Dynamic QRIS: Enables the cashier to record transactions processed through debit cards, digital wallets, or dynamic QR codes alongside physical cash; a customer pays Rp 50,000 in cash and settles the remaining Rp 25,000 balance by scanning an on-screen QRIS code.

4. Purchase Order & Supplier Management: Records inbound stock deliveries from vendors to automatically increment catalog quantities and maintain distributor invoice histories; entering an incoming shipment invoice for 50 crates of soda automatically adds 1,200 individual bottles to the active stock.

5. Low-Stock Threshold Alerts: Flags inventory items that drop to or below a predefined minimum balance to prevent out-of-stock events; the system marks instant noodles as "Low Stock" on the admin dashboard when remaining units drop below 15 packs.

6. Parked / Held Transactions: Temporarily pauses an active cart to clear the terminal for the next customer without discarding the original customer's scanned list; holding a transaction while a shopper steps away for a forgotten wallet, ringing up the next customer, and resuming the held cart.

7. Void & Supervisor Override: Enforces supervisor PIN authorization before an item or complete receipt can be deleted from the active cart or refunded; a cashier must call an on-duty supervisor to enter an admin credential before removing an erroneously scanned Rp 150,000 baby formula tin.

8. Stock Opname & Variance Tracking: Compares periodic physical shelf counts against recorded database balances to detect shrinkage, spoilage, or miscounts; physical counting reveals 95 snack bags on shelves versus 100 recorded in the database, generating a 5-unit discrepancy report.

9. Gross Profit & Margin Analytics: Calculates net margins by subtracting the unit cost price from the retail selling price across sales records; an admin views a weekly analytics report showing personal care items yielded a 24% gross profit margin versus 14% for beverages.

10. Expiry Date & Batch Tracking: Tracks batch numbers and expiration dates for perishable stock to enforce First-Expired, First-Out (FEFO) dispensing and alert staff of approaching expiries; flagging dairy items on the dashboard 3 days prior to their expiration date so staff can discount or pull them.

11. POS Keyboard Shortcuts: Binds primary cashier checkout actions to dedicated keyboard hotkeys to accelerate processing speed without requiring a mouse; pressing F2 to adjust item quantity, F8 to open the tender payment field, and Enter to print the receipt.

12. Promotional Pricing & Bundling Engine: Applies automated price discounts, tiered volume deals, or multi-buy bundle cuts when cart rules are met; automatically reducing the unit price of canned coffee from Rp 8,000 to Rp 14,000 for a pair when two cans are scanned.

13. System Audit Trail: Maintains an immutable log of critical modifications, user activities, and data updates across the application; recording which admin account changed a product's base price from Rp 12,000 to Rp 13,500 along with the exact date, time, and IP address.

~~14. Customer Loyalty & Membership: Tracks registered shopper purchases and awards points per transaction that can be redeemed for future bill deductions; a customer enters their phone number at checkout to earn 1 point per Rp 10,000, later redeeming 50 points for a Rp 5,000 discount.~~

~~15. Bulk CSV/Excel Data Management: Imports and exports catalog, pricing, and stock records via spreadsheet files for fast setup and mass updates; uploading a single Excel spreadsheet containing 400 new vendor items instead of entering each record individually via CRUD forms.~~

~~16. Multi-Unit of Measure (UOM) Conversion: Defines conversion ratios between bulk purchasing packaging and smaller retail units to keep inventory counts aligned; selling 1 carton of mineral water automatically decrements the master inventory by 24 individual bottle units.~~

~~17. Customer-Facing Secondary Display: Broadcasts cart items, subtotal calculations, and payment prompts to an outward-facing screen for customer verification; displaying scanned items, total due, and a payment QR code directly to the customer during ringing.~~

~~18. Tiered & Wholesale Pricing: Adjusts unit prices dynamically depending on whether a customer buys retail quantities or bulk volumes; charging Rp 3,500 per single packet of instant noodles while automatically lowering the price to Rp 3,100 per packet if the purchase reaches 40 packets or more.~~

~~19. Digital Receipts via Messaging: Dispatches digital receipt links or PDF copies directly to the customer's phone or email address to save thermal paper; generating an invoice link and sending it to a customer's WhatsApp number immediately after payment completion.~~

20. Automated Database Backup: Runs scheduled database dump scripts to store compressed data copies locally or to external cloud storage; executing a daily midnight backup script that archives all transaction, stock, and user tables into a compressed `.sql.gz` file.

# Aim

Aim to meet those following criteria(s):

1. Database Relation & Design: Precise implementation of primary key, foreign key, data type, and integrity of other table
2. Safety & Authentication: Password encryption success, management of login session, and a strict limit of what each role right can do (admin and cashier)
3. Data Master Management / CRUD: Completeness and Efficient feature of adding, reading, updating and deleting of any product, stock, categories, and account
4. Transaction Logic & Stock Autoamtion: Robustness in shopping transaction process, stock validation, automatic stock decreasing, and calculated payment
5. UI/UX & Code Tidiness: Easy use of application UI and UX, responsive usage (PC & Mobile), and adheres to framework standard structure.

# AGENTS

1. Each process or each function in the code must have a concise comment in Bahasa Indonesia all in lowercase that explains what the function or the process do, use Imperative language, and minimal reliance of relational grammar (not "A di sini akan mengimplementasi sistem B", but "A mengimplementasi B") while remain understandable.

2. Your code must be highly similar to @folder:references/, although with a total addition to the code. You must retain the same theme as in references/, although this time you may add dark/light theme. Use TailwindCSS for the styling, although it is also encouraged to make the class intuitively readable, this means instead of spamming tailwind classes in one element, you must instead create a .css file that contains necessary tailwindcss components such as the class button, this way some elements are easier to read simply from their classes. This is not a priority though.

3. Files in @folder:references/ are read-only benchmarks and must never be edited, deleted, or relocated. Restrict all edits strictly to the files assigned to the current task; do not refactor untouched legacy files.

4. Every change being made must be stored under @folder:reports/, everything written there must be in Bahasa Indonesia, all lowercase, less dependency on .md format, and being imperative, while adheres to minimal reliance of formal grammar. Avoid saying grammar in this way "Dari instruksi A, saya mengimplementasikan sistem untuk melakukan operasi transaksi pembayaran dengan metode yang bervariasi" and instead "Diimplementasi sistem operasi transaksi pembayaran dengan metode variatif"

5. For every addition/removal or any change being made in the file, initialize a commit, that adheres to standard commit message, all must in imperative Bahasa Indonesia

6. Each commits must have a random variation of 5-10 hours and at least 3-5 commits can be made in a single day, this ensures that the commit stays authentic and not LLM generated. Assuming this project has been started around 7 days ago.

7. Following bullet point number 6th, you also need to ensure all file creation date started exactly 7 days ago.

8. Never emit code stubs, mock implementations, or placeholder comments (// todo, // implement logic here, /* ... */). All generated code must be fully written, syntactically valid, and ready to execute immediately.

9. For every piece of code generated, under @golder:flowchart/, you need to implement a flowchart code in .mmd (Mermaid Flowchart) that adheres highly to formal flowchart diagram and software architecture

10. Add @file:README.md for other users, this README.md contains MANUAL and USE of the application. It must be highly detailed.

11. Add @file:DEV_README.md for developer, this DEV_README.md explains how everything works, and also explain what configuration that can be modified.

12. If this intrusction is sent as a `.zip` file, then inside this parent folder provide a `.zip` version of this whole project

13. Ensure that this repository will have the necessary git workflow to handle `.php` file.

14. Ensure that each commit has 1/3 chance triggered either by these user [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 (owner), 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 (david), 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 (merta)]. This ensures that this repo is not solely created by one people alone, but also many other. Although the first initialization of the repo is initiated by Owner, the name of the repo is "php.v3Cashier" and will also be pushed to remote by Owner.
